# 📬 Customer Feedback Analysis & Automated Response

A Python notebook that (1) finds the urgent, negative customer reviews using simple rules (no Machine Learning), (2) finds the most common complaint keywords, and (3) uses Generative AI (Google Gemini) to draft personalised, empathetic apology emails for the 3 most critical reviews.

## Files

| File | What it is |
|------|-----------|
| `customer_feedback_analysis.ipynb` | The main notebook (18 steps, each with a `WHY` and an `INSIGHT` comment) |
| `README.md` | This file |
| `generated_emails.csv` | Created when you run the notebook: the 3 reviews + AI emails |

## Dataset

**Women's E-Commerce Clothing Reviews** (Kaggle): https://www.kaggle.com/datasets/nicapotato/womens-ecommerce-clothing-reviews

Download it and keep the file name `Womens Clothing E-Commerce Reviews.csv`. It has the review text and a 1-5 star rating, plus product details (Title, Department, Class).

## My Approach

### 1. Cleaning the data (Steps 2-5)

- **Missing values:** Rows with no `Review Text` or no `Rating` are removed, because they give us nothing to analyse. Small side columns are filled instead of dropped: `Title` becomes `"No Title"` and `Division / Department / Class Name` become `"Unknown"`. Reviews that contain only spaces are also removed.
- **Duplicates:** Exact duplicate rows are removed so the same complaint is not counted twice.
- **Text cleaning:** A `clean_text()` function (1) makes the text lowercase, (2) removes apostrophes (`don't` → `dont`), (3) removes numbers, symbols and punctuation with a simple regex, and (4) removes extra spaces. The result is saved in a new column `clean_text`.
- The **original** `Review Text` is kept untouched, because the AI should read the customer's real words.

### 2. Rule-based logic (Steps 6-11)

No Machine Learning is used anywhere.

- **Critical review rule:** `Rating` is 1 or 2.
- **Top words:** `collections.Counter` counts words in the critical reviews after skipping a hand-written list of stop words (`the`, `and`, `is`, etc.) and very short words.
- **Complaint keyword watch-list:** Because common words can be neutral, I also made a focused dictionary of complaint words and short phrases (like `too small`, `cheap`, `itchy`, `see through`, `broken`, `late`, `rude`, `refund`) grouped into 6 categories: Fit & Size, Quality & Fabric, Looks & Color, Comfort, Service & Delivery, Disappointment & Returns. A keyword is counted **once per review**, and only as a whole word or phrase (spaces are added around the text so `thin` does not match `thing`).
- **Category view:** For each category, the notebook counts how many critical reviews mention at least one of its keywords, so the business can see the biggest problem area.
- Results are shown as charts and as a markdown table (Step 11).

### 3. Gen AI outreach (Steps 12-16)

- **Selecting 3 reviews:** From the critical reviews, repeated texts are removed, then sorted by lowest rating first and **longest** review second. The top 3 are the angriest and most detailed.
- **Prompt:** A system prompt makes the AI act as a Customer Support Agent with clear rules: mention the specific problems, show empathy, keep it under 120 words, offer one next step (return / exchange / refund help), and **never invent** order numbers, discount codes or policies. Each review's rating, product type, title and text are sent as the user prompt.
- **Output:** The 3 emails are displayed as markdown next to the original review and saved in `generated_emails.csv`.
- If an API call fails, the error is saved in place of the email instead of crashing the notebook.

## How to Run

### 1. Install the libraries

```bash
pip install pandas matplotlib seaborn jupyter google-genai
```

### 2. Add the dataset

Put `Womens Clothing E-Commerce Reviews.csv` in the same folder as the notebook. If it is somewhere else, change the path in **Step 1**.

### 3. Get a free Gemini API key

Create one in Google AI Studio: https://aistudio.google.com/apikey

### 4. Supply the API key (choose one)

**Option A: Paste it when asked (easiest).** Step 13 shows a hidden input box. Paste your key and press Enter. Nothing is stored in the notebook.

**Option B: Environment variable.** Set it *before* starting Jupyter, in the same terminal:

- Windows (PowerShell): `$env:GEMINI_API_KEY="your_key_here"`
- Windows (Command Prompt): `set GEMINI_API_KEY=your_key_here`
- Mac / Linux: `export GEMINI_API_KEY="your_key_here"`

Then run `jupyter notebook`.

> 🔒 Never write your key inside the notebook or upload it to GitHub.

### 5. Run the notebook

Open `customer_feedback_analysis.ipynb` and choose **Run All**. Save the notebook afterwards so the charts, insights tables and emails are stored in the file you submit.

## Troubleshooting

- **`FileNotFoundError`:** the CSV path in Step 1 is wrong.
- **`ModuleNotFoundError: google`:** run `pip install google-genai` and restart the kernel.
- **"Model not found" error in an email:** model names change over time. Update `MODEL_NAME` in Step 13 using the list at https://ai.google.dev/gemini-api/docs/models
- **Rate limit / quota error:** wait a minute and re-run Step 15.

## Limitations

- A star rating is only a rough signal of urgency (some 3-star reviews are urgent; some 1-star reviews are only about size).
- The keyword list is hand-made, so it can miss misspellings and new words.
- AI emails should be read by a human before sending.
